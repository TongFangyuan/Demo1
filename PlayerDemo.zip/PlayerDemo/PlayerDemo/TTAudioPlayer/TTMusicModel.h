//
//  TTMusicModel.h
//  PlayerDemo
//
//  Created by admin on 2018/11/28.
//  Copyright © 2018年 Tongfy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TTMusicModelProtocol.h"

@interface TTMusicModel : NSObject<TTMusicModelProtocol>

@end
